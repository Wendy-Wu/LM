dsmtpd Changelog
================

Here you can see the full list of changes between each dsmtpd release.

Version 0.3
-----------

Release date to be decided.

Version 0.2.2
-------------

Release on January 30th 2013.

- Fix the license
- Fix the author name


Version 0.2 & 0.2.1
-------------------

Release on January 21st 2013.

- Allow to store the incoming emails in a maildir via the '-d' argument

Version 0.1
-----------

Release on January 14th 2013.

- Implement a basic server
- Show the message in the log
