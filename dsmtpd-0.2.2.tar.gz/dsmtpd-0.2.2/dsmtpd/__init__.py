# -*- coding: utf-8 -*-
"""
    dsmtpd
    ~~~~~~

    :copyright: (c) 2013 by Stephane Wirtel <stephane@wirtel.be>
    :license: BSD, see LICENSE for more details
"""
__name__ = 'dsmtpd'
__version__ = '0.2.2'
__author__ = 'Stephane Wirtel'
__author_email__ = 'stephane@wirtel.be'
